# Arrow Escape — Android project

A small offline arrow-grid puzzle game packaged in a native Android WebView shell.

## Build an installable APK (Android Studio)
1. Install Android Studio on a computer from https://developer.android.com/studio.
2. Unzip this project folder.
3. In Android Studio choose **Open** and select the `ArrowEscape` folder (the one containing `settings.gradle`).
4. Accept the Gradle sync prompt and install the Android SDK Platform 35 if Android Studio asks.
5. Connect your Android phone with USB debugging enabled, or use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer `app-debug.apk` to your phone and tap it to install. If Android asks, allow **Install unknown apps** for the app you used to open the file. Only install APKs you built or trust.

## Notes
- The game works offline and does not request internet permission.
- This environment does not include the Android SDK/Gradle build tools, so the APK cannot be compiled here. The project source is ready to open and build in Android Studio.
